package viceCity.models.guns;

import viceCity.models.guns.BaseGun;

public class Pistol extends BaseGun {
    public static final int DEFAULT_PER_BARREL = 10;
    public static final int DEFAULT_TOTAL = 100;

    public Pistol(String name) {
        super(name, DEFAULT_PER_BARREL, DEFAULT_TOTAL);
    }

}
